/* ===================================================================
   Three.js 3D Plumbing & Heating Interactive Background Scene
   Jonathan R. Habacker Plumbing and Heating, LLC
   =================================================================== */

(function () {
  'use strict';

  const canvas = document.getElementById('hero-three-canvas');
  if (!canvas || typeof THREE === 'undefined') return;

  // Scene, Camera, Renderer
  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(
    60,
    window.innerWidth / window.innerHeight,
    0.1,
    1000
  );
  camera.position.z = 24;

  const renderer = new THREE.WebGLRenderer({
    canvas: canvas,
    alpha: true,
    antialias: true,
    powerPreference: 'high-performance'
  });
  renderer.setSize(window.innerWidth, window.innerHeight);
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));

  // Lighting
  const ambientLight = new THREE.AmbientLight(0xffffff, 0.7);
  scene.add(ambientLight);

  const redPointLight = new THREE.PointLight(0xd71920, 3, 50);
  redPointLight.position.set(10, 10, 10);
  scene.add(redPointLight);

  const copperPointLight = new THREE.PointLight(0xc87533, 2, 40);
  copperPointLight.position.set(-12, -8, 8);
  scene.add(copperPointLight);

  const bluePointLight = new THREE.PointLight(0x38bdf8, 1.5, 40);
  bluePointLight.position.set(0, 15, -5);
  scene.add(bluePointLight);

  // Group to hold all 3D mechanical elements
  const mainGroup = new THREE.Group();
  scene.add(mainGroup);

  // 1. Sleek Copper Mechanical Piping Network (Torus Knot & Ring Tubes)
  const pipeGeometry = new THREE.TorusKnotGeometry(7, 0.45, 120, 24, 2, 3);
  const pipeMaterial = new THREE.MeshStandardMaterial({
    color: 0xc87533,
    metalness: 0.85,
    roughness: 0.25,
    wireframe: false,
    emissive: 0x4a1805,
    emissiveIntensity: 0.2
  });
  const pipeMesh = new THREE.Mesh(pipeGeometry, pipeMaterial);
  mainGroup.add(pipeMesh);

  // Concentric floating valve rings
  const ringGeo1 = new THREE.TorusGeometry(10.5, 0.12, 16, 100);
  const ringMat1 = new THREE.MeshStandardMaterial({
    color: 0xd71920,
    metalness: 0.9,
    roughness: 0.1,
    emissive: 0xd71920,
    emissiveIntensity: 0.4
  });
  const ring1 = new THREE.Mesh(ringGeo1, ringMat1);
  ring1.rotation.x = Math.PI / 3;
  mainGroup.add(ring1);

  const ringGeo2 = new THREE.TorusGeometry(12, 0.08, 16, 100);
  const ringMat2 = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    metalness: 0.8,
    roughness: 0.2,
    transparent: true,
    opacity: 0.35
  });
  const ring2 = new THREE.Mesh(ringGeo2, ringMat2);
  ring2.rotation.y = Math.PI / 4;
  mainGroup.add(ring2);

  // 2. Dual-Stream Particle System: Heating Embers (Red/Amber) & Fluid Flow (Cyan/White)
  const particleCount = 420;
  const positions = new Float32Array(particleCount * 3);
  const colors = new Float32Array(particleCount * 3);
  const scales = new Float32Array(particleCount);

  const colorRed = new THREE.Color(0xd71920);
  const colorGold = new THREE.Color(0xf59e0b);
  const colorCyan = new THREE.Color(0x38bdf8);
  const colorWhite = new THREE.Color(0xffffff);

  for (let i = 0; i < particleCount; i++) {
    const i3 = i * 3;
    // Spiral distribution around the central mechanical piping
    const angle = Math.random() * Math.PI * 2;
    const radius = 5 + Math.random() * 12;
    const height = (Math.random() - 0.5) * 20;

    positions[i3] = Math.cos(angle) * radius;
    positions[i3 + 1] = height;
    positions[i3 + 2] = Math.sin(angle) * radius;

    // Split particles into thermal (heating) and fluid (plumbing)
    const isThermal = Math.random() > 0.45;
    const chosenColor = isThermal
      ? (Math.random() > 0.5 ? colorRed : colorGold)
      : (Math.random() > 0.5 ? colorCyan : colorWhite);

    colors[i3] = chosenColor.r;
    colors[i3 + 1] = chosenColor.g;
    colors[i3 + 2] = chosenColor.b;

    scales[i] = Math.random() * 2.5 + 0.8;
  }

  const particleGeometry = new THREE.BufferGeometry();
  particleGeometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  particleGeometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));

  // Custom circular glowing particle texture
  function createParticleTexture() {
    const c = document.createElement('canvas');
    c.width = 64;
    c.height = 64;
    const ctx = c.getContext('2d');
    const grad = ctx.createRadialGradient(32, 32, 0, 32, 32, 32);
    grad.addColorStop(0, 'rgba(255,255,255,1)');
    grad.addColorStop(0.3, 'rgba(255,255,255,0.8)');
    grad.addColorStop(0.7, 'rgba(255,255,255,0.2)');
    grad.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, 64, 64);
    return new THREE.CanvasTexture(c);
  }

  const particleMaterial = new THREE.PointsMaterial({
    size: 0.45,
    vertexColors: true,
    transparent: true,
    opacity: 0.85,
    blending: THREE.AdditiveBlending,
    map: createParticleTexture(),
    depthWrite: false
  });

  const particleSystem = new THREE.Points(particleGeometry, particleMaterial);
  mainGroup.add(particleSystem);

  // Position group slightly toward the right for artistic backdrop framing
  mainGroup.position.x = window.innerWidth > 900 ? 5 : 0;
  mainGroup.position.y = 0;

  // Mouse interaction variables
  let mouseX = 0;
  let mouseY = 0;
  let targetX = 0;
  let targetY = 0;
  const windowHalfX = window.innerWidth / 2;
  const windowHalfY = window.innerHeight / 2;

  window.addEventListener('mousemove', function (e) {
    mouseX = (e.clientX - windowHalfX) * 0.0008;
    mouseY = (e.clientY - windowHalfY) * 0.0008;
  });

  // Responsive Resize
  window.addEventListener('resize', function () {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
    mainGroup.position.x = window.innerWidth > 900 ? 5 : 0;
  });

  // Performance: Pause animation when Hero is scrolled out of viewport
  let isHeroVisible = true;
  const heroSection = document.getElementById('hero');
  if ('IntersectionObserver' in window && heroSection) {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          isHeroVisible = entry.isIntersecting;
        });
      },
      { threshold: 0.05 }
    );
    observer.observe(heroSection);
  }

  // Animation Loop
  let clock = new THREE.Clock();

  function animate() {
    requestAnimationFrame(animate);

    if (!isHeroVisible) return;

    const delta = clock.getDelta();
    const elapsedTime = clock.getElapsedTime();

    // Smooth mouse parallax lerp
    targetX += (mouseX - targetX) * 0.05;
    targetY += (mouseY - targetY) * 0.05;

    mainGroup.rotation.y = elapsedTime * 0.12 + targetX * 1.5;
    mainGroup.rotation.x = Math.sin(elapsedTime * 0.08) * 0.2 + targetY * 1.5;

    // Counter rotate rings
    ring1.rotation.z += 0.005;
    ring2.rotation.z -= 0.003;

    // Animate particles flowing
    const pos = particleGeometry.attributes.position.array;
    for (let i = 0; i < particleCount; i++) {
      const i3 = i * 3;
      pos[i3 + 1] += Math.sin(elapsedTime * 1.5 + i) * 0.015;
      if (pos[i3 + 1] > 12) pos[i3 + 1] = -12;
    }
    particleGeometry.attributes.position.needsUpdate = true;

    // Dynamic light pulsation
    redPointLight.intensity = 2.5 + Math.sin(elapsedTime * 2) * 0.8;
    copperPointLight.intensity = 1.8 + Math.cos(elapsedTime * 1.5) * 0.5;

    renderer.render(scene, camera);
  }

  animate();
})();
