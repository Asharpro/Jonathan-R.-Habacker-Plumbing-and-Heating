/* ===================================================================
   Jonathan R. Habacker Plumbing and Heating, LLC - Main Interactions
   =================================================================== */

document.addEventListener('DOMContentLoaded', function () {
  'use strict';

  // 1. Sticky Header & Scroll Spy
  const header = document.querySelector('.main-header');
  const navLinks = document.querySelectorAll('.nav-link');
  const sections = document.querySelectorAll('section[id]');
  const backToTopBtn = document.querySelector('.back-to-top');

  window.addEventListener('scroll', function () {
    const scrollPos = window.scrollY;

    // Header background toggle
    if (scrollPos > 40) {
      header.classList.add('scrolled');
    } else {
      header.classList.remove('scrolled');
    }

    // Back to top button visibility
    if (scrollPos > 400) {
      backToTopBtn.classList.add('visible');
    } else {
      backToTopBtn.classList.remove('visible');
    }

    // Scroll spy
    sections.forEach((sec) => {
      const top = sec.offsetTop - 120;
      const height = sec.offsetHeight;
      const id = sec.getAttribute('id');

      if (scrollPos >= top && scrollPos < top + height) {
        navLinks.forEach((link) => {
          link.classList.remove('active');
          if (link.getAttribute('href') === '#' + id) {
            link.classList.add('active');
          }
        });
      }
    });
  });

  // Back to Top Click
  if (backToTopBtn) {
    backToTopBtn.addEventListener('click', function (e) {
      e.preventDefault();
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

  // 2. Mobile Menu Toggle
  const mobileToggle = document.querySelector('.mobile-toggle');
  const navMenu = document.querySelector('.nav-menu');

  if (mobileToggle && navMenu) {
    mobileToggle.addEventListener('click', function () {
      navMenu.classList.toggle('open');
      const icon = mobileToggle.querySelector('i');
      if (icon) {
        if (navMenu.classList.contains('open')) {
          icon.className = 'fas fa-times';
        } else {
          icon.className = 'fas fa-bars';
        }
      }
    });

    // Close on link click
    navMenu.querySelectorAll('.nav-link').forEach((link) => {
      link.addEventListener('click', function () {
        navMenu.classList.remove('open');
        const icon = mobileToggle.querySelector('i');
        if (icon) icon.className = 'fas fa-bars';
      });
    });
  }

  // 3. Interactive Before & After Image Slider
  const sliderContainer = document.querySelector('.ba-comparison-slider');
  const afterImage = document.querySelector('.ba-after');
  const handle = document.querySelector('.ba-handle');

  if (sliderContainer && afterImage && handle) {
    let isDragging = false;

    function updateSlider(xPos) {
      const rect = sliderContainer.getBoundingClientRect();
      let offsetX = xPos - rect.left;
      if (offsetX < 0) offsetX = 0;
      if (offsetX > rect.width) offsetX = rect.width;

      const percentage = (offsetX / rect.width) * 100;
      afterImage.style.width = percentage + '%';
      handle.style.left = percentage + '%';
    }

    // Mouse events
    sliderContainer.addEventListener('mousedown', function (e) {
      isDragging = true;
      updateSlider(e.clientX);
    });

    window.addEventListener('mouseup', function () {
      isDragging = false;
    });

    window.addEventListener('mousemove', function (e) {
      if (!isDragging) return;
      updateSlider(e.clientX);
    });

    // Touch events for mobile
    sliderContainer.addEventListener('touchstart', function (e) {
      isDragging = true;
      if (e.touches.length > 0) {
        updateSlider(e.touches[0].clientX);
      }
    });

    window.addEventListener('touchend', function () {
      isDragging = false;
    });

    window.addEventListener('touchmove', function (e) {
      if (!isDragging) return;
      if (e.touches.length > 0) {
        updateSlider(e.touches[0].clientX);
      }
    });
  }

  // 4. Gallery Category Filter Tabs
  const filterTabs = document.querySelectorAll('.filter-tab');
  const galleryItems = document.querySelectorAll('.gallery-item');

  filterTabs.forEach((tab) => {
    tab.addEventListener('click', function () {
      filterTabs.forEach((t) => t.classList.remove('active'));
      tab.classList.add('active');

      const filterVal = tab.getAttribute('data-filter');

      galleryItems.forEach((item) => {
        const itemCategory = item.getAttribute('data-category');
        if (filterVal === 'all' || itemCategory === filterVal) {
          item.style.display = 'block';
          setTimeout(() => {
            item.style.opacity = '1';
            item.style.transform = 'scale(1)';
          }, 10);
        } else {
          item.style.opacity = '0';
          item.style.transform = 'scale(0.95)';
          setTimeout(() => {
            item.style.display = 'none';
          }, 250);
        }
      });
    });
  });

  // 5. FAQ Accordion
  const faqItems = document.querySelectorAll('.faq-item');

  faqItems.forEach((item) => {
    const questionBtn = item.querySelector('.faq-question');
    if (questionBtn) {
      questionBtn.addEventListener('click', function () {
        const isActive = item.classList.contains('active');

        // Close all other items for a clean accordion effect
        faqItems.forEach((f) => f.classList.remove('active'));

        if (!isActive) {
          item.classList.add('active');
        }
      });
    }
  });

  // 6. Contact Form Submission Handling
  const contactForm = document.getElementById('main-contact-form');
  const formFeedback = document.getElementById('contact-form-feedback');

  if (contactForm && formFeedback) {
    contactForm.addEventListener('submit', function (e) {
      e.preventDefault();

      // Collect data
      const name = contactForm.querySelector('[name="name"]').value.trim();
      const phone = contactForm.querySelector('[name="phone"]').value.trim();
      const service = contactForm.querySelector('[name="service"]').value;

      if (!name || !phone) {
        alert('Please provide your name and phone number so Jonathan can reach you.');
        return;
      }

      const submitBtn = contactForm.querySelector('button[type="submit"]');
      const originalText = submitBtn.innerHTML;
      submitBtn.disabled = true;
      submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Submitting...';

      setTimeout(function () {
        submitBtn.disabled = false;
        submitBtn.innerHTML = '<i class="fas fa-check"></i> Request Received!';

        formFeedback.className = 'form-feedback success';
        formFeedback.innerHTML = `
          <strong><i class="fas fa-check-circle"></i> Thank you, ${name}!</strong><br>
          Your request for <em>${service || 'service'}</em> has been dispatched directly to Jonathan. We will call you at <strong>${phone}</strong> shortly to discuss your estimate!
        `;
        contactForm.reset();

        setTimeout(() => {
          submitBtn.innerHTML = originalText;
        }, 5000);
      }, 1000);
    });
  }

  // 7. Get a Quote Modal Handling
  const modal = document.getElementById('quote-modal');
  const quoteButtons = document.querySelectorAll('.trigger-quote-modal');
  const modalClose = document.querySelectorAll('.modal-close');
  const modalForm = document.getElementById('modal-quote-form');
  const modalFeedback = document.getElementById('modal-form-feedback');

  quoteButtons.forEach((btn) => {
    btn.addEventListener('click', function (e) {
      e.preventDefault();
      if (modal) {
        modal.classList.add('open');
        document.body.style.overflow = 'hidden';
      }
    });
  });

  modalClose.forEach((btn) => {
    btn.addEventListener('click', function () {
      if (modal) {
        modal.classList.remove('open');
        document.body.style.overflow = '';
      }
    });
  });

  // Close modal when clicking on backdrop
  if (modal) {
    modal.addEventListener('click', function (e) {
      if (e.target === modal) {
        modal.classList.remove('open');
        document.body.style.overflow = '';
      }
    });
  }

  // Modal Form Submit
  if (modalForm && modalFeedback) {
    modalForm.addEventListener('submit', function (e) {
      e.preventDefault();

      const name = modalForm.querySelector('[name="name"]').value.trim();
      const phone = modalForm.querySelector('[name="phone"]').value.trim();

      const submitBtn = modalForm.querySelector('button[type="submit"]');
      const originalText = submitBtn.innerHTML;
      submitBtn.disabled = true;
      submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Submitting...';

      setTimeout(function () {
        submitBtn.disabled = false;
        submitBtn.innerHTML = '<i class="fas fa-check"></i> Quote Requested!';

        modalFeedback.className = 'form-feedback success';
        modalFeedback.innerHTML = `
          <strong><i class="fas fa-check-circle"></i> Thank you, ${name}!</strong><br>
          Jonathan will call you at <strong>${phone}</strong> with your customized quote.
        `;
        modalForm.reset();

        setTimeout(() => {
          if (modal) {
            modal.classList.remove('open');
            document.body.style.overflow = '';
          }
          submitBtn.innerHTML = originalText;
          modalFeedback.className = 'form-feedback';
          modalFeedback.innerHTML = '';
        }, 3500);
      }, 900);
    });
  }

  // 8. Smooth scrolling for internal anchor links
  document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
    anchor.addEventListener('click', function (e) {
      const targetId = this.getAttribute('href');
      if (targetId === '#' || targetId === '') return;
      const targetEl = document.querySelector(targetId);
      if (targetEl) {
        e.preventDefault();
        const headerOffset = 84;
        const elementPosition = targetEl.getBoundingClientRect().top;
        const offsetPosition = elementPosition + window.pageYOffset - headerOffset;

        window.scrollTo({
          top: offsetPosition,
          behavior: 'smooth'
        });
      }
    });
  });

  // 9. Legal Modal (Privacy Policy & Terms of Service)
  const legalModal = document.getElementById('legal-modal');
  const legalTitle = document.getElementById('legal-modal-title');
  const legalBody = document.getElementById('legal-modal-body');

  const privacyBtn = document.querySelector('.open-privacy-modal');
  const termsBtn = document.querySelector('.open-terms-modal');

  if (privacyBtn && legalModal) {
    privacyBtn.addEventListener('click', function (e) {
      e.preventDefault();
      legalTitle.innerText = 'Privacy Policy';
      legalBody.innerHTML = `
        <p><strong>Last Updated: 2026</strong></p><br>
        <p>At <strong>Jonathan R. Habacker Plumbing and Heating, LLC</strong>, your privacy is paramount. When you submit your name, phone number, email address, or project location through our website or phone lines, we use this information exclusively to communicate regarding your plumbing, heating, or mechanical estimate and service appointment.</p><br>
        <p><strong>Information Sharing:</strong> We do NOT sell, rent, trade, or share your personal contact details with third-party marketers or data aggregators. Information is used strictly by our licensed personnel to deliver quotes and perform services.</p><br>
        <p><strong>Contact:</strong> If you have any questions regarding how your data is handled, please contact us directly at <strong>(860) 671-3645</strong> or at 153 Mathew Rd, Winsted, CT 06098.</p>
      `;
      legalModal.classList.add('open');
      document.body.style.overflow = 'hidden';
    });
  }

  if (termsBtn && legalModal) {
    termsBtn.addEventListener('click', function (e) {
      e.preventDefault();
      legalTitle.innerText = 'Terms of Service';
      legalBody.innerHTML = `
        <p><strong>Last Updated: 2026</strong></p><br>
        <p><strong>Licensing &amp; Coverage:</strong> Jonathan R. Habacker Plumbing and Heating, LLC is licensed by the State of Connecticut under Contractor License <strong>PLM.0291194-P1</strong> and carries comprehensive liability insurance. All services are performed in accordance with Connecticut state and local plumbing and mechanical building codes.</p><br>
        <p><strong>Estimates &amp; Scope:</strong> Written and verbal estimates are based on visible existing conditions. Unforeseen concealed conditions (such as sub-slab defects, historical plumbing code violations, or hazardous materials) will be brought to the client's attention with an adjusted scope before work proceeds.</p><br>
        <p><strong>Warranty:</strong> All labor and manufacturer-warranted equipment are backed by our commitment to quality craftsmanship. For warranty inquiries, please contact <strong>(860) 671-3645</strong>.</p>
      `;
      legalModal.classList.add('open');
      document.body.style.overflow = 'hidden';
    });
  }

  // Auto-update current year in footer
  const yearEl = document.getElementById('current-year');
  if (yearEl) {
    yearEl.textContent = new Date().getFullYear();
  }
});
